#include <stdio.h>

int issorted(int v[], int start, int end) {
    int middle;
    if(start==end) return 1;
    if (end-start==1 && v[start]>v[end]) return 0;
    middle = (start+end)/2;
    return (issorted(v, start, middle) && issorted(v, middle+1, end));
}

int main() {
    int v[100], i, n;
    scanf("%d", &n);
    for(i=0; i<n; i++) 
        scanf("%d", &v[i]);
    if(issorted(v, 0, n-1)==1) printf("vectorul este sortat");
        else printf("vectorul nu este sortat");
}