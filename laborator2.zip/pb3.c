#include <stdio.h>

int cautarepoz(int v[], int x, int start, int end) {
    int middle;
    middle=(start+end)/2;
    if(v[middle]<=x && v[middle+1]>=x)  return middle+1;
    if(v[middle]<x) return cautarepoz(v, x, middle+1, end);
        else return cautarepoz(v, x, start, middle);
}

int main() {
    int n, v[100], i, x;
    scanf("%d", &x);
    scanf("%d", &n);
    for(i=0; i<n; i++) 
        scanf("%d", &v[i]);
    printf("pozitia la care ar trebui inserat %d este %d", x, cautarepoz(v, x, 0, n-1));
}