#include <stdio.h>

int sum(int v[], int start, int end) {
    int middle;
    if(start==end) return v[start];
    middle = (start+end)/2;
    return (sum(v, start, middle) + sum(v, middle+1, end));
}

int main() {
    int v[100], i, n;
    scanf("%d", &n);
    for(i=0; i<n; i++) 
        scanf("%d", &v[i]);
    printf("%d", sum(v, 0, n-1));
}