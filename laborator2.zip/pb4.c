#include <stdio.h>
#include <stdlib.h>

int n;
int *w;
void ms();
void mergeSort(int *v, int start, int end);
void merge(int *v, int lowPtr, int highPtr, int end);

int main() {
    int i;
    scanf("%d", &n);
    w=malloc(n*sizeof(int));
    for(i=0; i<n; i++) {
        scanf("%d", &w[i]);
    }
    ms();
    for(i=0; i<n; i++)
        printf("%d ", w[i]);
}

void ms() {
    int *v=malloc(n*sizeof(int));
    mergeSort(v, 0, n-1);
}

void mergeSort(int v[], int start, int end) {
    int middle;
    if(start==end) return;
    middle=(start+end)/2;
    mergeSort(v, start, middle);
    mergeSort(v, middle+1, end);
    merge(v, start, middle+1, end);
}

void merge(int *v, int lowPtr, int highPtr, int end) {
    int j=0;
    int start=lowPtr;
    int middle=highPtr-1;
    int dim=end-start+1;
    while(lowPtr<=middle && highPtr<=end)
        if(w[lowPtr]<w[highPtr])
            v[j++]=w[lowPtr++];
        else v[j++]=w[highPtr++];
    while(lowPtr<=middle)
        v[j++]=w[lowPtr++];
    while(highPtr<=end)
        v[j++]=w[highPtr++]; 
    for(j=0; j<dim; j++)
        w[start+j]=v[j];
}
