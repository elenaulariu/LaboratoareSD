#include "exercitiul2.h"
#include <stdio.h>
#include <stdlib.h>

void insert(List **list, int value) {
    List *newNode = malloc (sizeof(List));
    newNode->value=value;
    newNode->next=NULL;
    if(*list==NULL)
        *list=newNode;
    else {
        List *lastNode=*list;
        while(lastNode->next!=NULL)
            lastNode=lastNode->next;
        lastNode->next=newNode;
    }
}

List* merge(List* l1, List* l2) {
    if(l1==NULL)
        return l2;
    if(l2==NULL)
        return l1;
    if(l1->value<l2->value) {
        l1->next=merge(l1->next, l2);
        return l1;
    }
    else {
        l2->next=merge(l1, l2->next);
        return l2;
    }
}

void print_list(List *list) {
    List *it = list;
    printf("[");
    while (it != NULL) {
        printf("%d ", it->value);
        it = it->next;
    }
    printf("]\n");
}

int main() {
    List *l1 = NULL;
    List *l2 = NULL;
    insert(&l1, 1);
    insert(&l1, 2);
    insert(&l1, 4);
    insert(&l2, 1);
    insert(&l2, 3);
    insert(&l2, 4);
    insert(&l2, 5);
    List *l=merge(l1, l2);
    print_list(l);
}