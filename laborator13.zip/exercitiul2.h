#ifndef __EXERCITIUL2_H__
#define __EXERCITIUL2_H__

typedef struct List {
    int value;
    struct List *next;
} List;

#endif