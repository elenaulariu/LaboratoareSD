#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int is_subsequence(char *w1, char *w2) {
    if(*w1=='\0') 
        return 1;
    if(*w2=='\0') 
        return 0;
    if(*w1==*w2)
        return is_subsequence(w1+1, w2+1);
    return is_subsequence(w1, w2+1);
}

int main () {
    printf("%d\n", is_subsequence("bat", "basket"));
    printf("%d\n", is_subsequence("bye", "butterfly"));
}