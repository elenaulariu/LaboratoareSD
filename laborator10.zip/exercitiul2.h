#ifndef _EXERCITIUL2_H_
#define _EXERCITIUL2_H_

typedef struct undirected_graph
{
    int num_nodes;
    int **adj_mat;
} u_graph;
u_graph *init_graph(int n);
void insert_edge(u_graph *graph, int from, int to);
void remove_edge(u_graph *graph, int from, int to);
void destroy_graph(u_graph *graph);
void topological_sort(u_graph *graph, int source, int *visited);

#endif