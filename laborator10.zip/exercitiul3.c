#include "exercitiul1.h"
#include <stdio.h>
#include <stdlib.h>
#define INFINITY 9999

w_graph *init_graph(int n) {
    int i;
    w_graph *graph=(w_graph *) calloc(1, sizeof(w_graph));
    graph->num_nodes=n;
    graph->adj_mat=calloc(n, sizeof(int*));
    for(i=0; i<n; i++) 
        graph->adj_mat[i]=calloc(n,sizeof(int));
    return graph;
}

void insert_edge(w_graph *graph, int from, int to, int weight) {
    graph->adj_mat[from][to]=weight;
}

void remove_edge(w_graph *graph, int from, int to) {
    graph->adj_mat[from][to]=0;
}

void destroy_graph(w_graph *graph) {
    int i;
    for(i=0; i<graph->num_nodes; i++)
        free(graph->adj_mat[i]);
    free(graph->adj_mat);
    free(graph);
}

void dijkstra(w_graph *graph, int source) {
    int distance[5], visited[5], pred[5], cost[5][5];
    int count, dmin, nextnode;
    int i, j;
    for(i=0; i<graph->num_nodes; i++) {
        for(j=0; j<graph->num_nodes; j++) {
            if(graph->adj_mat[i][j]==0) {
                cost[i][j]=INFINITY;
            }
            else cost[i][j]=graph->adj_mat[i][j];
        }
    }
    for(i=0; i<graph->num_nodes; i++) {
        pred[i]=source;
        distance[i]=cost[source][i];
        visited[i]=0;
    }
    distance[source]=0;
    visited[source]=1;
    count=1;
    while(count<graph->num_nodes-1) {
        dmin=INFINITY;
        for(i=0; i<graph->num_nodes; i++) {
            if(distance[i]<dmin && visited[i]==0)   {
                dmin=distance[i];
                nextnode=i;
            }
            visited[nextnode]=1;
        
            for(j=0; j<graph->num_nodes; j++) {
                if(visited[j]==0) {
                    if(distance[j]>dmin+cost[nextnode][j]) {
                        distance[j]=dmin+cost[nextnode][j];
                        pred[j]=nextnode;
                    }
                }
            }
        }
        count++;
    }
    for(i=0; i<graph->num_nodes; i++) {
        if(i!=source) {
            printf("Distanta la nodul %d = %d\n", i, distance[i]);
        }
    }
}

int main() {

    ///////////////////// INIT_GRAPH //////////////////////////
    w_graph *g = init_graph(5);
    
    ///////////////////// INSERT_EDGE //////////////////////////
    insert_edge(g, 0, 1, 4);
    insert_edge(g, 0, 2, 2);
    insert_edge(g, 2, 1, 1);
    insert_edge(g, 1, 2, 3);
    insert_edge(g, 1, 3, 2);
    insert_edge(g, 1, 4, 3);
    insert_edge(g, 2, 3, 4);
    insert_edge(g, 4, 3, 1);

    /////////////////////// DISTANCE //////////////////////////
    dijkstra(g, 0);

    ////////////////////// DESTROY_GRAPH //////////////////////////
    destroy_graph(g);
}