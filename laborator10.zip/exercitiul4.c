#include "exercitiul1.h"
#include <stdio.h>
#include <stdlib.h>
#define INFINITY 9999

w_graph *init_graph(int n) {
    int i;
    w_graph *graph=(w_graph *) calloc(1, sizeof(w_graph));
    graph->num_nodes=n;
    graph->adj_mat=calloc(n, sizeof(int*));
    for(i=0; i<n; i++) 
        graph->adj_mat[i]=calloc(n,sizeof(int));
    return graph;
}

void insert_edge(w_graph *graph, int from, int to, int weight) {
    graph->adj_mat[from][to]=weight;
}

void remove_edge(w_graph *graph, int from, int to) {
    graph->adj_mat[from][to]=0;
}

void destroy_graph(w_graph *graph) {
    int i;
    for(i=0; i<graph->num_nodes; i++)
        free(graph->adj_mat[i]);
    free(graph->adj_mat);
    free(graph);
}

void bellmanford(w_graph *graph, int source) {
    int distance[5], pred[5];
    int i, j, count;
    for(i=0; i<graph->num_nodes; i++) {
        pred[i]=0;
        distance[i]=INFINITY;
    }
    distance[source]=0;
    count=1;
    while(count<graph->num_nodes-1) {
        for(i=0; i<graph->num_nodes; i++) {
            for(j=0; j<graph->num_nodes; j++) {
                if(graph->adj_mat[i][j]!=0){
                    if(distance[j]>distance[i]+graph->adj_mat[i][j]) {
                        distance[j]=distance[i]+graph->adj_mat[i][j];
                        pred[j]=i;
                    }
                }
            }
        } 
        count++;
    }
    for(i=0; i<graph->num_nodes; i++) {
        if(distance[i]>distance[source]+graph->adj_mat[source][i]) {
            printf("negative cycle\n");
        }
        printf("Distanta la nodul %d = %d\n", i, distance[i]);
    }
}

int main() {

    ///////////////////// INIT_GRAPH //////////////////////////
    w_graph *g = init_graph(5);
    
    ///////////////////// INSERT_EDGE //////////////////////////
    insert_edge(g, 0, 1, 1);
    insert_edge(g, 0, 2, 10);
    insert_edge(g, 1, 3, 2);
    insert_edge(g, 2, 3, -10);
    insert_edge(g, 3, 4, 3);

    /////////////////////// DISTANCE //////////////////////////
    bellmanford(g, 0);

    ////////////////////// DESTROY_GRAPH //////////////////////////
    destroy_graph(g);
}