#include "exercitiul2.h"
#include <stdio.h>
#include <stdlib.h>

u_graph *init_graph(int n) {
    int i;
    u_graph *graph=(u_graph *) calloc(1, sizeof(u_graph));
    graph->num_nodes=n;
    graph->adj_mat=calloc(n, sizeof(int*));
    for(i=0; i<n; i++) 
        graph->adj_mat[i]=calloc(n,sizeof(int));
    return graph;
}

void insert_edge(u_graph *graph, int from, int to) {
    graph->adj_mat[from][to]=1;
}

void remove_edge(u_graph *graph, int from, int to) {
    graph->adj_mat[from][to]=0;
}

void destroy_graph(u_graph *graph) {
    int i;
    for(i=0; i<graph->num_nodes; i++)
        free(graph->adj_mat[i]);
    free(graph->adj_mat);
    free(graph);
}

void topological_sort(u_graph *graph, int source, int *visited) {
    visited[source]=1;
    int ok=0;
    int i;
    for (i=0; i<graph->num_nodes; i++) {
        if(graph->adj_mat[source][i] && visited[i]==0) {
            ok=1;
            topological_sort(graph, i, visited);
        }
    }
    printf("%d ", source);
    if(ok==0) {
        for(i=0; i<graph->num_nodes; i++) {
            if(visited[i]==0) {
                topological_sort(graph, i, visited);
                break;
            }
        }
    }
    
}

int main() {
    ///////////////////// INIT_GRAPH //////////////////////////
    u_graph *g = init_graph(6);

    ///////////////////// INSERT_EDGE //////////////////////////
    insert_edge(g, 5, 0);
    insert_edge(g, 4, 0);
    insert_edge(g, 5, 2);
    insert_edge(g, 4, 1);
    insert_edge(g, 2, 3);
    insert_edge(g, 3, 1);
    
    ///////////////////// TOPOLOGICAL_SORT //////////////////////////
    int *tp_visited = calloc(g->num_nodes, sizeof(int));
    topological_sort(g, 0, tp_visited);
    printf("\n");
    free(tp_visited);

    ////////////////////// DESTROY_GRAPH //////////////////////////
    destroy_graph(g);
}