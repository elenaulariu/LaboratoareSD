#ifndef _EXERCITIUL1_H_
#define _EXERCITIUL1_H_

typedef struct weighted_graph{
    int num_nodes;
    int **adj_mat;
} w_graph;

w_graph *init_graph(int n);
void insert_edge(w_graph *graph, int from, int to, int weight);
void remove_edge(w_graph *graph, int from, int to);
void destroy_graph(w_graph *graph);
void print_adj_matrix(w_graph *graph);

#endif