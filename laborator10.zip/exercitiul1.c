#include "exercitiul1.h"
#include <stdio.h>
#include <stdlib.h>

w_graph *init_graph(int n) {
    int i;
    w_graph *graph=(w_graph *) calloc(1, sizeof(w_graph));
    graph->num_nodes=n;
    graph->adj_mat=calloc(n, sizeof(int*));
    for(i=0; i<n; i++) 
        graph->adj_mat[i]=calloc(n,sizeof(int));
    return graph;
}

void insert_edge(w_graph *graph, int from, int to, int weight) {
    graph->adj_mat[from][to]=weight;
}

void remove_edge(w_graph *graph, int from, int to) {
    graph->adj_mat[from][to]=0;
}

void destroy_graph(w_graph *graph) {
    int i;
    for(i=0; i<graph->num_nodes; i++)
        free(graph->adj_mat[i]);
    free(graph->adj_mat);
    free(graph);
}

void print_adj_matrix(w_graph *graph) {
    for (int i = 0; i < graph->num_nodes; i++) {
        for (int j = 0; j < graph->num_nodes; j++) {
            printf("%d ", graph->adj_mat[i][j]);
        }
        printf("\n");
    }
}

int main() {

    ///////////////////// INIT_GRAPH //////////////////////////
    w_graph *g = init_graph(5);
    
    ///////////////////// INSERT_EDGE //////////////////////////
    printf("----------INSERT_EDGE----------\n");
    insert_edge(g, 0, 1, 4);
    insert_edge(g, 0, 2, 2);
    insert_edge(g, 2, 1, 1);
    insert_edge(g, 1, 2, 3);
    insert_edge(g, 1, 3, 2);
    insert_edge(g, 1, 4, 3);
    insert_edge(g, 2, 3, 4);
    insert_edge(g, 4, 3, 1);
    print_adj_matrix(g);

    /////////////////////// REMOVE_EDGE //////////////////////////
    printf("----------REMOVE_EDGE----------\n");
    remove_edge(g, 1, 2);
    remove_edge(g, 1, 4);
    print_adj_matrix(g);

    ////////////////////// DESTROY_GRAPH //////////////////////////
    destroy_graph(g);
}