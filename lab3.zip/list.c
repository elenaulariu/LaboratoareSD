#include "list.h"
#include <stdlib.h>
#include <stdio.h>

//TODO: Sa se implementeze urmatoarele functii:

int is_empty(List *list) {
    if(list == NULL)
        return 1;
    return 0;
}

void print_list(List *list) {
    List *it = list;
    while (it != NULL) {
        printf("%d->", it->value);
        it = it->next;
    }
    printf("NULL\n");
}

void insert(List **list, int value) {
    List *newNode = malloc (sizeof(List));
    newNode->value=value;
    newNode->next=NULL;
    if(*list==NULL)
        *list=newNode;
    else {
        List *lastNode=*list;
        while(lastNode->next!=NULL)
            lastNode=lastNode->next;
        lastNode->next=newNode;
    }
}

void delete(List **list, int value) {
    List *temp;
    if((*list)->value==value) {
        temp=*list;
        *list=(*list)->next;
        free(temp);
    }
    else {
        List *curent = *list;
        while(curent->next!=NULL) {
            if(curent->next->value==value) {
                temp=curent->next;
                curent->next=curent->next->next;
                free(temp);
                break;
            }
            else curent=curent->next;
        }
    }
}

void delete_all(List **list) {
    List *temp;
    while(*list!=NULL) {
        temp=*list;
        *list=(*list)->next;
        free(temp);
    }
}


int get_length(List *list) {
    int length=0;
    List *current=list;
    while(current!=NULL) {
        length++;
        current=current->next;
    }
    if (length) return length;
    return 0;

}

int contains(List *list, int value) {
    List *temp=list;
    while(temp!=NULL) {
        if(temp->value==value)
            return 1;
        temp=temp->next;
    }
    return 0;
}

int get_kth_last_elem(List *list, int k) {
    List *temp1=list, *temp2=list;
    for(int i=0; i<k; i++) 
        if(temp1!=NULL)
            temp1=temp1->next;
        else return -1;
    while(temp1!=NULL) {
        temp1=temp1->next;
        temp2=temp2->next;
    }
    return temp2->value;
}

int main() {
    List *list = NULL;

    ///////////////////////// IS_EMPTY ////////////////////////////
    printf("Test 1 is_empty: %d\n", is_empty(list)); // is_empty -> 1
    
    insert(&list, 7);
    printf("Test 2 is_empty: %d\n\n", is_empty(list)); // is_empty -> 0

    // ///////////////////////// INSERT & PRINT_LIST ////////////////////////////
    insert(&list, 10);
    insert(&list, 30);
    insert(&list, 3);
    insert(&list, 12);
    insert(&list, 30);
    printf("Test insert & print_list: ");
    print_list(list); // Should print 7->10->30->3->12-30->NULL
    printf("\n");

    // ///////////////////////// CONTAINS ////////////////////////////
    printf("Test 1 contains(list, 12): %d\n", contains(list, 12)); // contains(list,12) -> 1
    printf("Test 2 contains(list, 5): %d\n\n", contains(list, 5)); // contains(list,5) -> 0

    // ///////////////////////// DELETE ////////////////////////////
    delete(&list, 30);
    delete(&list, 30);
    printf("Test delete(list, 30) (twice): ");
    print_list(list); // Should print 7->10->3->12->NULL

    delete(&list, 7);
    printf("Test delete(list, 7): ");
    print_list(list); // Should print 10->3->12->NULL
    printf("\n");

    // ///////////////////////// GET_LENGTH ////////////////////////////
    printf("Test get_length: %d\n", get_length(list)); // 3
    printf("\n");

    // ///////////////////////// DELETE_ALL ////////////////////////////
    delete_all(&list);
    printf("Test delete_all: ");
    print_list(list); // Should print NULL
    printf("\n");

    // ///////////////////////// GET_KTH_LAST_ELEM ////////////////////////////
    insert(&list, 10);
    insert(&list, 20);
    insert(&list, 30);
    insert(&list, 1);
    insert(&list, 2);
    insert(&list, 3);
    insert(&list, 9);
    insert(&list, 7);
    print_list(list); // Should print 10->20->30->1->2->3->9->7->NULL
    printf("Test get_kth_last_elem(list, 9): %d\n", get_kth_last_elem(list, 9)); // Should print -1
    printf("Test get_kth_last_elem(list, 5): %d\n",get_kth_last_elem(list, 5)); // Should print 1




















    return 0;
}