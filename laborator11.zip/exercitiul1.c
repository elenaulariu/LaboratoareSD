#include "exercitiul1.h"
#include <stdio.h>
#include <stdlib.h>

weighted_graph_t *init_graph(int n) {
    int i;
    weighted_graph_t *graph=(weighted_graph_t *) calloc(1, sizeof(weighted_graph_t));
    graph->num_nodes=n;
    graph->num_edges=0;
    graph->adj_mat=calloc(n, sizeof(int*));
    for(i=0; i<n; i++) 
        graph->adj_mat[i]=calloc(n,sizeof(int));
    return graph;
}

void insert_edge(weighted_graph_t *graph, int from, int to, int weight) {
    graph->adj_mat[from][to]=weight;
    graph->num_edges++;
}

weighted_edge_t* graph_get_all_edges (weighted_graph_t *graph) {
    weighted_edge_t *edge = malloc(graph->num_edges*sizeof(weighted_edge_t));
    int i, j, k=0;
    for(i=0; i<graph->num_nodes; i++) {
        for(j=0; j<graph->num_nodes; j++) {
            if(graph->adj_mat[i][j]!=0) {
                edge[k].from=i;
                edge[k].to=j;
                edge[k].weight=graph->adj_mat[i][j];
                k++;
            }
        }
    }
    return edge;
}

void destroy_graph(weighted_graph_t *graph) {
    int i;
    for(i=0; i<graph->num_nodes; i++)
        free(graph->adj_mat[i]);
    free(graph->adj_mat);
    free(graph);
}

int main () {
    ////// EXEMPLU //////
    weighted_graph_t *g = init_graph(5);
    insert_edge(g, 0, 1, 4);
    insert_edge(g, 0, 2, 2);
    insert_edge(g, 2, 1, 1);
    insert_edge(g, 1, 2, 3);
    insert_edge(g, 1, 3, 2);
    insert_edge(g, 1, 4, 3);
    insert_edge(g, 2, 3, 4);
    insert_edge(g, 4, 3, 1);
    weighted_edge_t *edge = graph_get_all_edges(g);
    for(int i=0; i<g->num_edges; i++) {
        printf("%d %d %f\n", edge[i].from, edge[i].to, edge[i].weight);
    }
    free(edge);
    destroy_graph(g);
}
