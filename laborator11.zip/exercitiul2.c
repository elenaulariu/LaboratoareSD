#include "exercitiul2.h"
#include <stdio.h>
#include <stdlib.h>

weighted_graph_t *init_graph(int n) {
    int i;
    weighted_graph_t *graph=(weighted_graph_t *) calloc(1, sizeof(weighted_graph_t));
    graph->num_nodes=n;
    graph->num_edges=0;
    graph->adj_mat=calloc(n, sizeof(int*));
    for(i=0; i<n; i++) 
        graph->adj_mat[i]=calloc(n,sizeof(int));
    return graph;
}

void insert_edge(weighted_graph_t *graph, int from, int to, int weight) {
    graph->adj_mat[from][to]=weight;
    graph->adj_mat[to][from]=weight;
    graph->num_edges++;
}

weighted_edge_t* graph_get_all_edges (weighted_graph_t *graph) {
    weighted_edge_t *edge = malloc(graph->num_edges*sizeof(weighted_edge_t));
    int i, j, k=0;
    for(i=0; i<graph->num_nodes; i++) {
        for(j=i+1; j<graph->num_nodes; j++) {
            if(graph->adj_mat[i][j]!=0) {
                edge[k].from=i;
                edge[k].to=j;
                edge[k].weight=graph->adj_mat[i][j];
                k++;
            }
        }
    }
    return edge;
}

int find(subset_t *subsets, int i) {
    if(subsets[i].parent!=i) {
        subsets[i].parent=find(subsets, subsets[i].parent);
    }
    return subsets[i].parent;
}

void Union(subset_t *subsets, int x, int y) {
    int xroot=find(subsets, x), yroot=find(subsets, y);
    if(subsets[xroot].rank<subsets[yroot].rank)
        subsets[xroot].parent=yroot;
    else if(subsets[xroot].rank>subsets[yroot].rank)
        subsets[yroot].parent=xroot;
        else {
            subsets[yroot].parent=xroot;
            subsets[xroot].rank++;
        }
}

int cmp(const void* a, const void* b) {
    weighted_edge_t* a1=(weighted_edge_t*) a;
    weighted_edge_t* b1=(weighted_edge_t*) b;
    return a1->weight > b1->weight;
}

double minimum_spanning_tree (weighted_graph_t * graph) {
    int V=graph->num_nodes, v, i=0, e=0, x, y;
    double minimumcost=0;
    weighted_edge_t *edge = graph_get_all_edges(graph);
    weighted_edge_t result[V];
    qsort(edge, graph->num_edges, sizeof(edge[0]), cmp);
    subset_t* subsets = (subset_t*)malloc(V * sizeof(subset_t));
    for(v=0; v<V; v++) {
        subsets[v].parent=v;
        subsets[v].rank=0;
    }
    while(e<V-1 && i<graph->num_edges) {
        weighted_edge_t next_edge=edge[i++];
        x=find(subsets, next_edge.from);
        y=find(subsets, next_edge.to);
        if(x!=y) {
            result[e++]=next_edge;
            Union(subsets, x, y);
        }
    }
    for(i=0; i<e; i++) {
        printf("%d -- %d = %f\n", result[i].from, result[i].to, result[i].weight);
        minimumcost=minimumcost+result[i].weight;
    }
    free(edge);
    free(subsets);
    return minimumcost;
}

void destroy_graph(weighted_graph_t *graph) {
    int i;
    for(i=0; i<graph->num_nodes; i++)
        free(graph->adj_mat[i]);
    free(graph->adj_mat);
    free(graph);
}

int main () {
    ////// EXEMPLU //////
    weighted_graph_t *g = init_graph(5);
    insert_edge(g, 0, 1, 4);
    insert_edge(g, 0, 2, 2);
    insert_edge(g, 2, 1, 1);
    insert_edge(g, 1, 3, 2);
    insert_edge(g, 1, 4, 3);
    insert_edge(g, 2, 3, 4);
    insert_edge(g, 4, 3, 1);
    printf("%f", minimum_spanning_tree(g));
    destroy_graph(g);
}
