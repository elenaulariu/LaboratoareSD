#ifndef _EXERCITIUL1_H
#define _EXERCITIUL1_H

typedef struct {
    int from ;
    int to ;
    double weight ;
} weighted_edge_t ;

typedef struct {
    int num_nodes;
    int num_edges;
    float **adj_mat;
} weighted_graph_t;

weighted_graph_t *init_graph(int n);
void insert_edge(weighted_graph_t *graph, int from, int to, int weight);
weighted_edge_t* graph_get_all_edges (weighted_graph_t *graph);
void destroy_graph(weighted_graph_t *graph);

#endif