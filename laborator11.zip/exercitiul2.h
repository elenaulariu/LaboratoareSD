#ifndef _EXERCITIUL2_H
#define _EXERCITIUL2_H

typedef struct {
    int from ;
    int to ;
    double weight ;
} weighted_edge_t ;

typedef struct {
    int num_nodes;
    int num_edges;
    float **adj_mat;
} weighted_graph_t;

typedef struct {
    int parent;
    int rank;
}subset_t;

weighted_graph_t *init_graph(int n);
void insert_edge(weighted_graph_t *graph, int from, int to, int weight);
weighted_edge_t* graph_get_all_edges (weighted_graph_t *graph);
int find(subset_t *subsets, int i);
void Union(subset_t *subsets, int x, int y);
int cmp(const void* a, const void* b);
double minimum_spanning_tree ( weighted_graph_t * graph );
void destroy_graph(weighted_graph_t *graph);

#endif