#include "heap.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

/* Returneaza indexul parintelui nodului n. */
static int get_parent(int n) {
    if (n<=0) return-1;
    return (n-1)/2;
}

/* Returneaza indexul copilului stang al nodului n. */
static int get_left_child(int n) {
    return 2*n+1;
}

/* Returneaza indexul copilului drept al nodului n. */
static int get_right_child(int n) {
    return 2*n+2;
}

/* Initializeaza coada de prioritati. */
heap *init_heap(int capacity) {
    heap *h=malloc(sizeof(*h));
    h->arr=malloc(capacity*sizeof(int));
    h->size=0;
    h->capacity=capacity;
    return h;
}

/* Insereaza un nou element in heap. (Cand se va atinge capacitatea maxima a
heap-ului nu se vor mai putea insera elemente) */
void insert(heap *h, int value) {
    if(h->size==h->capacity) return;
    int i=h->size, aux;
    h->arr[i]=value;
    while(i>0 && h->arr[get_parent(i)]<h->arr[i]) {
        aux=h->arr[i];
        h->arr[i]=h->arr[get_parent(i)];
        h->arr[get_parent(i)]=aux;
        i=get_parent(i);
    }
    h->size++;
}

/* Propaga in jos in heap valoarea nodului de pe pozitia i astfel incat sa se 
refaca propietatea heap-ului. */
void heapify(heap *h, int i) {
    int left, right, max=i, aux;
    left=get_left_child(i);
    right=get_right_child(i);
    if(left<h->size && h->arr[left]>h->arr[max]) 
        max=left;
    if(right<h->size && h->arr[right]>h->arr[max])
        max=right;
    if(max!=i) {
        aux=h->arr[max];
        h->arr[max]=h->arr[i];
        h->arr[i]=aux;
        heapify(h, max);
    }
}

/* Sterge elementul maxim si reface proprietatea cozii de prioritati. */
int delete_max(heap *h) {
    int hmax;
    if(h->size<=0) return -1;
    hmax=h->arr[0];
    h->arr[0]=h->arr[h->size-1];
    h->size--;
    heapify(h,0);
    return hmax;
}

void print_heap(heap *h) {
    printf("[");
    for (int i = 0; i < h->size; i++) {
        printf("%d ", h->arr[i]);
    }
    printf("]\n");
}

/* Sorteaza un vector v cu n elemente, folosind heap-ul implementat anterior.
 Functia va returna vectorul sortat crescator. */
static int *heap_sort(int *v, int n) {
    int i, aux;
    heap *h=init_heap(n);
    for(i=0; i<n; i++) {
        insert(h, v[i]);
    }
    for(i=h->size-1; i>=1; i--) {
        aux=h->arr[0];
        h->arr[0]=h->arr[h->size-1];
        h->arr[h->size-1]=aux;
        h->size--;
        heapify(h, 0);
    }
    for(i=0; i<n; i++)
        v[i]=h->arr[i];
    return v;
}

int main() {
    heap *h = init_heap(10);
    
    /////////////////////// INIT_HEAP ///////////////////////
    assert(h != NULL && h->arr != NULL && h->size == 0 && h->capacity == 10);

    /////////////////////// INSERT ///////////////////////
    int v[] = {35, 33, 42, 10, 14, 19, 27, 44, 26, 31};
    int v_size = sizeof(v) / sizeof(v[0]);
    for (int i = 0; i < v_size; i++) {
        insert(h, v[i]);
    }
    insert(h, 0); // This value should not be inserted (the heap is already full)

    printf("Test insert: ");
    print_heap(h); // Should print [44 42 35 33 31 19 27 10 26 14]
    assert(h->size == v_size);
    assert(get_parent(0) < 0);
    assert(h->arr[get_parent(2)] == 44);
    assert(h->arr[get_left_child(2)] == 19);
    assert(h->arr[get_right_child(1)] == 31);

    /////////////////////// DELETE & HEAPIFY ///////////////////////
    assert(delete_max(h) == 44);
    printf("Test delete: ");
    print_heap(h);
    assert(delete_max(h) == 42);
    printf("Test delete: ");
    print_heap(h);

    /////////////////////// HEAPSORT ///////////////////////
    int arr[] = {9, 6, 8, 3, 1, 7, 8, 4, 12};
    int arr_size = sizeof(arr) / sizeof(arr[0]);
    int *sorted_arr = heap_sort(arr, arr_size);
    printf("Sorted array: [");
    for (int i=0; i < arr_size; i++) {
        printf("%d ", sorted_arr[i]);
    }
    printf("]\n");
    return 0;
}
