#include "trie.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

trie_node* init_trie() {
    trie_node *node=NULL;
    node=malloc(sizeof(trie_node));
    if(node) {
        int index;
        node->is_end_of_word=0;
        for(index=0; index<ALPHABET_SIZE; index++)
            node->children[index]=NULL;
    }
    return node;
}

void insert(trie_node *trie, char *word) {
    int level, index, length=strlen(word);
    trie_node *current=trie;
    for(level=0; level<length; level++){
        index=word[level]-'a';
        if(current->children[index]==NULL)
            current->children[index]=init_trie();
        current=current->children[index];
    }
    current->is_end_of_word=1;
}

int contains(trie_node *trie, char *word){
    int level, index, length=strlen(word);
    trie_node *current=trie;
    for(level=0; level<length; level++) {
        index=word[level]-'a';
        if(current->children[index]==NULL) 
            return 0;
        current=current->children[index];
    }
    return (current!=NULL && current->is_end_of_word==1);
}

void destroy_trie(trie_node *trie) {
    int index;
    if(trie==NULL) return;
    for(index=0; index<ALPHABET_SIZE; index++) {
        if(trie->children[index]!=NULL)
            destroy_trie(trie->children[index]);
    }
    free(trie);
}

int main() {
    trie_node *trie = init_trie();

    insert(trie, "abc");
    insert(trie, "abcde");
    insert(trie, "clarinet");

    printf("abc: %d\n",contains(trie, "abc")); // Should be 1
    printf("abcde: %d\n",contains(trie, "abcde")); // Should be 1
    printf("abcdef: %d\n",contains(trie, "abcdef")); // Should be 0
    printf("clarinet: %d\n",contains(trie, "clarinet")); // Should be 1
    printf("clar: %d\n",contains(trie, "clar")); // Should be 0

    // TODO: Verificati functia destroy_tree folosind valgrind
    destroy_trie(trie);
    
    return 0;
}
