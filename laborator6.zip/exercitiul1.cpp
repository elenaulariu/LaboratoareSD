#include "helpers.h"
#include "bst_node.h"

const double minValue(bst_node_t **root_ptr) {
  if((*root_ptr)->left==NULL) return (*root_ptr)->value;
  return minValue(&(*root_ptr)->left);
}

void insert(bst_node_t **root_ptr, const double value) {
    if (*root_ptr==NULL) {
      *root_ptr=(bst_node_t*)malloc(sizeof(bst_node_t));
      (*root_ptr)->value=value;
      (*root_ptr)->left=NULL;
      (*root_ptr)->right=NULL;
      (*root_ptr)->parent=NULL;
    }
    else if (value <= (*root_ptr)->value){
      insert(&(*root_ptr)->left, value);
      (*root_ptr)->left->parent=*root_ptr;
    }
    else if (value > (*root_ptr)->value) {
      insert(&(*root_ptr)->right, value);
      (*root_ptr)->right->parent=*root_ptr;
    }
}

bst_node_t *search(bst_node_t * const root, const double value) {
  if(root==NULL)
    return NULL;
  if (root->value==value)
    return root;
  if (value<root->value)
    return search(root->left, value);
  else if (value>root->value)
    return search(root->right, value);
}

void remove(bst_node_t **root_ptr, const double value) {
  if(*root_ptr==NULL) return;
  else if(value<(*root_ptr)->value) {
    remove(&(*root_ptr)->left, value);  
  }
  else if(value>(*root_ptr)->value) {
    remove(&(*root_ptr)->right, value);
  }
  else {
    if((*root_ptr)->left==NULL) {
      bst_node_t *temp=(*root_ptr)->right;
      free(*root_ptr);
      *root_ptr=temp;
    }
    else if((*root_ptr)->right==NULL) {
      bst_node_t *temp=(*root_ptr)->left;
      free(*root_ptr);
      *root_ptr=temp;
    }
    else {
      (*root_ptr)->value=minValue(&(*root_ptr)->right);
      remove(&(*root_ptr)->right, (*root_ptr)->value);
    }
  }
}
