#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

#include "bst_node.h"
#include "helpers.h"

size_t max(size_t a, size_t b) {
  if(a>=b) return a;
  return b;
}

size_t tree_height(bst_node_t * const root) {
  if (root==NULL) return 0;
  return max(tree_height(root->left), tree_height(root->right))+1;
}

size_t node_height(bst_node_t * const node) {
  if (node==NULL)
    return -1;
  if(node->parent==NULL) return 0;
  return node_height(node->parent)+1;
}
