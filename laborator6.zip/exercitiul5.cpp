#include <algorithm>

#include "helpers.h"
#include "bst_node.h"

size_t diameter(bst_node_t * const node) {
  return -1;
}
