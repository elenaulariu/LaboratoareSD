#include "exercitiul1.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

hashmap *init(int n) {
    int i;
    hashmap *hm=malloc(sizeof(hashmap));
    hm->size=n;
    hm->buckets=malloc(n*sizeof(map_entry*));
    for(i=0; i<n; i++) {
        hm->buckets[i]=NULL;
    }
    return hm;
}

int hash(char *word) {
    int i, hsh=0;
    for(i=0; i<strlen(word); i++) {
        hsh=hsh+(i+1)*word[i];
    }
    return hsh;
}

int get(hashmap *m, char *key) {
    int idx_table;
    idx_table=hash(key)%m->size;
    map_entry *temp=m->buckets[idx_table];
    while(temp!=NULL) {
        if(strcmp(temp->key, key)==0) 
            return temp->value;
        temp=temp->next;
    }
    return -1;
}

void put(hashmap *m, char *key, int value) {
    int idx_table;
    idx_table=hash(key)%m->size;
    map_entry *temp=m->buckets[idx_table];
    while(temp!=NULL) {
        if(strcmp(temp->key, key)==0) {
            temp->value=value;
            return;
        }
        temp=temp->next;
    }
    map_entry *newNode=malloc(sizeof(map_entry));
    newNode->value=value;
    newNode->key=key;
    newNode->next=NULL;
    newNode->prev=NULL;
    if(m->buckets[idx_table]==NULL) {
        m->buckets[idx_table]=newNode;
    }
    else {
        temp=m->buckets[idx_table];
        while (temp->next!=NULL) {
            temp=temp->next;            
        }
        newNode->prev=temp;
        temp->next=newNode;
    }
}

void destoy(hashmap *m) {
    map_entry *temp;
    int i;
    for(i=0; i<m->size; i++) {
        while (m->buckets[i]!=NULL) {
            if(m->buckets[i]->next==NULL) {
                temp=m->buckets[i];
                m->buckets[i]=NULL;
                free(temp);
            }
            else {
                temp=m->buckets[i];
                m->buckets[i]=m->buckets[i]->next;
                free(temp);
            }
        }
    }
    free(m->buckets);
    free(m);
}

void print(hashmap *m) {
    int i;
    FILE *out;
    out=fopen("out.txt", "wt");
    map_entry *temp;
    for(i=0; i<m->size; i++) {
        temp=m->buckets[i];
        while (temp!=NULL) {
            fprintf(out, "%s %d\n", temp->key, temp->value);
            temp=temp->next;
        }
    }
    fclose(out);
}

int main() {
    hashmap *hm=init(256);
    char *word;
    char sep[2]=" ";
    char text[1000]="Nor again is there anyone who loves or pursues or desires to obtain pain of itself because it is pain but because occasionally circumstances occur in which toil and pain can procure him some great pleasure To take a trivial example which of us ever undertakes laborious physical exercise except to obtain some advantage from it But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences or one who avoids a pain that produces no resultant pleasure On the other hand we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment so blinded by desire that they cannot foresee";
    int value;
    word=strtok(text, sep);
    while (word!=NULL) {
        if(get(hm, word)==-1) {
            put(hm, word, 1);
        }
        else put(hm, word, get(hm, word)+1);
        word=strtok(NULL, sep);
    }
    // FUNCTIA HASH //
    printf("FUNCTIA HASH\n");
    char *wrd="and";
    printf("hash(and)=%d\n", hash(wrd));
    // FUNCTIA GET //
    printf("FUNCTIA GET\n");
    printf("cuvantul and apare de: %d ori\n", get(hm, "and"));
    printf("elephant: %d \n", get(hm, "elephant"));
    // FUNCTIA PUT //
    printf("FUNCTIA PUT\n");
    put(hm, "elephant", 1);
    printf("cuvantul elephant apare de: %d ori\n", get(hm, "elephant"));
    put(hm, "and", get(hm, "and")+1);
    printf("cuvantul and apare de: %d ori\n", get(hm, "and"));
    print(hm);
    destoy(hm);
}