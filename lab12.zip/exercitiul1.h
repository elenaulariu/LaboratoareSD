#ifndef _EXERCITIUL1_H
#define _EXERCITIUL1_H

typedef struct node
{
    char *key;
    int value;
    struct node *next;
    struct node *prev;
} map_entry;

typedef struct
{
    map_entry **buckets;
    int size;
} hashmap;

hashmap *init(int n);
int hash(char *word);
int get(hashmap *m, char *key);
void put(hashmap *m, char *key, int value);
void destroy(hashmap *m);
void print(hashmap *m);

#endif