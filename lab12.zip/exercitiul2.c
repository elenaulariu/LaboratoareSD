#include "exercitiul1.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

hashmap *init(int n) {
    int i;
    hashmap *hm=malloc(sizeof(hashmap));
    hm->size=n;
    hm->buckets=malloc(n*sizeof(map_entry*));
    for(i=0; i<n; i++) {
        hm->buckets[i]=NULL;
    }
    return hm;
}

int hash(char *word) {
    int i, hsh=0;
    for(i=0; i<strlen(word); i++) {
        hsh=hsh+(i+1)*word[i];
    }
    return hsh;
}

int get(hashmap *m, char *key) {
    int idx_table;
    idx_table=hash(key)%m->size;
    map_entry *temp=m->buckets[idx_table];
    while(temp!=NULL) {
        if(strcmp(temp->key, key)==0) 
            return temp->value;
        temp=temp->next;
    }
    return -1;
}

void put(hashmap *m, char *key, int value) {
    int idx_table;
    idx_table=hash(key)%m->size;
    map_entry *temp=m->buckets[idx_table];
    while(temp!=NULL) {
        if(strcmp(temp->key, key)==0) {
            temp->value=value;
            return;
        }
        temp=temp->next;
    }
    map_entry *newNode=malloc(sizeof(map_entry));
    newNode->value=value;
    newNode->key=key;
    newNode->next=NULL;
    newNode->prev=NULL;
    if(m->buckets[idx_table]==NULL) {
        m->buckets[idx_table]=newNode;
    }
    else {
        temp=m->buckets[idx_table];
        while (temp->next!=NULL) {
            temp=temp->next;            
        }
        newNode->prev=temp;
        temp->next=newNode;
    }
}

void destoy(hashmap *m) {
    map_entry *temp;
    int i;
    for(i=0; i<m->size; i++) {
        while (m->buckets[i]!=NULL) {
            if(m->buckets[i]->next==NULL) {
                temp=m->buckets[i];
                m->buckets[i]=NULL;
                free(temp);
            }
            else {
                temp=m->buckets[i];
                m->buckets[i]=m->buckets[i]->next;
                free(temp);
            }
        }
    }
    free(m->buckets);
    free(m);
}

int samewords(hashmap *m1, hashmap *m2) {
    int i;
    for(i=0; i<m1->size; i++) {
        map_entry *temp=m1->buckets[i];
        while(temp!=NULL) {
            if(get(m2, temp->key)!=temp->value)
                return 0;
            temp=temp->next;
        }
    }
    return 1;
}

int main() {
    hashmap *m1=init(256), *m2=init(256);
    char *word;
    char text1[1000]="I am a smart kid I love chess and football I want pizza and french fries now";
    char text2[1000]="a smart kid I am I love pizza and french fries now I want chess and football";
    char sep[2]=" ";
    int value;
    word=strtok(text1, sep);
    while (word!=NULL) {
        if(get(m1, word)==-1) {
            put(m1, word, 1);
        }
        else put(m1, word, get(m1, word)+1);
        word=strtok(NULL, sep);
    }
    word=strtok(text2, sep);
    while (word!=NULL) {
        if(get(m2, word)==-1) {
            put(m2, word, 1);
        }
        else put(m2, word, get(m2, word)+1);
        word=strtok(NULL, sep);
    }
    printf("%d", samewords(m1, m2));
    destoy(m1);
    destoy(m2);
}