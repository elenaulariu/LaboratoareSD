#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

// Initializeaza o stiva. (0.5 p)
Stack* init_stack()
{
    Stack* s=malloc(sizeof(Stack));
    s->size=0;
    s->top=NULL;
    return s;
}

// Returneaza 1 daca stiva este goala si 0 in caz contrar. (0.5 puncte)
int is_empty_stack(Stack *s)
{
    if(s->size==0)
        return 1;
    return 0;
}

// Returneaza numarul de elemente din stiva. (0.5 puncte).
int stack_size(Stack *s)
{
    return s->size;
}

// Adauga un element in stiva. (0.5 p)
void push(Stack *s, double x)
{
    Node *newNode = malloc(sizeof(Node));
    newNode->value=x;
    newNode->next=s->top;
    s->top=newNode;
    s->size++;
}

// Sterge (si dezaloca) elementul din varful stivei. (Intoarce 1 daca operatia a reusit si 0 in caz contrar) (0.5 p)
int pop(Stack *s)
{
    Node *temp;
    if(s->top==NULL) return 0;
    temp=s->top;
    s->top=s->top->next;
    free(temp);
    s->size--;
    return 1;
}

// Returneaza elementul din varful stivei. (0.5 puncte)
double top(Stack *s)
{
    if(s->top==NULL) return 0;
    return s->top->value;
}

void print_stack(Stack *s)
{
    if (!s)
        return;

    printf("[");
    for (Node *it = s->top; it != NULL; it = it->next) {
        printf("%lf ", it->value);
    }
    printf("]");
}
